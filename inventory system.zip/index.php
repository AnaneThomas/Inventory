<?php include('include/header.php'); ?>

    <h1>Hello, world!</h1>

<?php include('include/footer.php'); ?>